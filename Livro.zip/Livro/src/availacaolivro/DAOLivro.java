
package availacaolivro;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DAOLivro {

    Livro livro;
    private PreparedStatement pstm;
    public String sql;
    ConectaBD conecta; 
    
    public DAOLivro(){
        livro = new Livro();
        conecta = new ConectaBD();
        conecta.getConnection();
    }
    
    public boolean inserirLivro(){
       try {
           // Conectando com BD e inserindo dados na tabela Produto.
           sql = "insert into Servico values (null,?,?,?,?,?,?,?)";
           pstm = conecta.connection.prepareStatement(sql);
           pstm.setString(1, livro.getIdLivro());
           pstm.setString(2, livro.getTitulo());
           pstm.setString(3, livro.getSinopse());
           pstm.setString(4, livro.getEditora());
           pstm.setInt(5, livro.getNrPaginas());
           pstm.setInt(6, livro.getAno());
           pstm.setDouble(7, livro.getPreco());
           
           pstm.executeUpdate();
           conecta.close();
           return true;
       }catch(SQLException erro){
           JOptionPane.showMessageDialog(null, erro);
           return false;
       }
        
    }
}
    

