
package availacaolivro;

public class AvailacaoLivro {

   
    public static void main(String[] args) {
        
    }
    
}
