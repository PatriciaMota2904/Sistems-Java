
package availacaolivro;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DAO {
    Livro livro;
  
    private PreparedStatement pstm;
    private Statement stm;
    public ResultSet rs;
    public String sql;
    ConectaBD conecta; 
    
    public DAO(){
        livro = new Livro();
    
    }
    
    public boolean inserirLivro(){
        conecta = new ConectaBD();
        conecta.getConnection();
        try {
           // Conectando com BD e inserindo dados na tabela Produto.
           sql = "insert into Produto values (?,?,?,?,?,?,?)";
           pstm = conecta.connection.prepareStatement(sql);
           pstm.setString(1, livro.getIdLivro());
           pstm.setString(2, livro.getTitulo());
           pstm.setString(3, livro.getSinopse());
           pstm.setString(4, livro.getEditora());
           pstm.setInt(5, livro.getNrPaginas());
           pstm.setInt(6, livro.getAno());
           pstm.setDouble(7, livro.getPreco());
           pstm.executeUpdate();
           return true;
       }catch(SQLException erro){
           JOptionPane.showMessageDialog(null, erro);
           return false;
       }
        finally{
           conecta.close();
       }
           
    }
   
    public int buscaIdLivro(){
        int IdLivro = 0;
        conecta = new ConectaBD();
        conecta.getConnection();
        try{
            String sqlId = "select max(idlivro) from livro";
            stm = conecta.connection.createStatement();
            rs = stm.executeQuery(sqlId);
            while (rs.next()) {
                IdLivro = rs.getInt(1);
            }
            IdLivro++;
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err);
        }
        conecta.close();
        return IdLivro;
    }
}

    

