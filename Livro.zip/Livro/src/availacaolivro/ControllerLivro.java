
package availacaolivro;

import javax.swing.JFormattedTextField;

public class ControllerLivro {
       public boolean receberFormLivro(String idLivro, String titulo, String sinopse,
            String editora, String nrPaginas, String ano, String preco){
        DAO daoLivro = new DAO();
        preco = preco.replace(".", "");
        preco = preco.replace(",", ".");
        daoLivro.livro.setIdLivro(idLivro);
        daoLivro.livro.setTitulo(titulo);
        daoLivro.livro.setSinopse(sinopse);
        daoLivro.livro.setEditora(editora);
        daoLivro.livro.setNrPaginas(Integer.parseInt(nrPaginas));
        daoLivro.livro.setAno(Integer.parseInt(ano));
        daoLivro.livro.setPreco(Double.parseDouble(preco));
        
        return daoLivro.inserirLivro();
    }

    Object receberFormServico(String text, String text0, String text1, String text2, String text3, double preco) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object receberFormLivro(String text, String text0, String text1, String text2, String text3, String text4, JFormattedTextField tfPreco) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    

