package View;
import Controller.ControllerLivro;
import Controller.DiversosMetodos;
import Model.DAOLivro;
import Model.ModeloTabela;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class CadastroLivro extends javax.swing.JFrame {

    ControllerLivro cl;
    DAOLivro daoLivro;
    int botaoFoto = 1;
    ImageIcon imagem1 = null;
    File arquivoFoto=null;
    String imagemUrl = "C:/Users/ricardo.amaral/Documents/NetBeansProjects/Livraria/src/View/Imagens/";
    String imagemOrigem = "";
    String imagemDestino = "";
    String imagemNovoNome = "";
    String imagemBanco =  "";
    
            
    public CadastroLivro() {
        initComponents();
        daoLivro = new DAOLivro();
        habilitaDesabilitaBotoes(true, false, false, false, false, false);
        habilitaDesabilitaCampos(false, false, false, false, false, false);
        preencherTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btImagem = new javax.swing.JToggleButton();
        lbImagem = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfTitulo = new javax.swing.JTextField();
        lbCodigo = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tfSinopse = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        tfAno = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        tfPaginas = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        tfValor = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        tfDtLivro = new javax.swing.JFormattedTextField();
        jPanel5 = new javax.swing.JPanel();
        btNovo = new javax.swing.JButton();
        btGravar = new javax.swing.JButton();
        btEditar = new javax.swing.JButton();
        btExcluir = new javax.swing.JButton();
        btLimpar = new javax.swing.JButton();
        btSair = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbLivros = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Cadastro de Livro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        btImagem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/foto.png"))); // NOI18N
        btImagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btImagemActionPerformed(evt);
            }
        });

        lbImagem.setText(".");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(btImagem))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(lbImagem)))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addComponent(lbImagem)
                .addGap(64, 64, 64)
                .addComponent(btImagem)
                .addContainerGap())
        );

        jLabel1.setText("Código: ");

        jLabel3.setText("Título:");

        jLabel4.setText("Sinopse:");

        lbCodigo.setText(".");

        tfSinopse.setColumns(20);
        tfSinopse.setRows(5);
        tfSinopse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tfSinopseMouseClicked(evt);
            }
        });
        tfSinopse.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfSinopseKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(tfSinopse);

        jLabel5.setText("Ano:");

        try {
            tfAno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel6.setText("Páginas: ");

        try {
            tfPaginas.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel7.setText("Valor:");

        try {
            tfValor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###,##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel2.setText("Dt.Livro: ");

        try {
            tfDtLivro.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfAno, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfPaginas, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(tfValor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfTitulo))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lbCodigo)
                                .addGap(48, 48, 48)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfDtLivro, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lbCodigo)
                    .addComponent(jLabel2)
                    .addComponent(tfDtLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(tfPaginas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(tfValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tfAno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        btNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/novo.png"))); // NOI18N
        btNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNovoActionPerformed(evt);
            }
        });

        btGravar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/gravar.png"))); // NOI18N
        btGravar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGravarActionPerformed(evt);
            }
        });

        btEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/editar.png"))); // NOI18N
        btEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditarActionPerformed(evt);
            }
        });

        btExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/excluir.png"))); // NOI18N
        btExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btExcluirActionPerformed(evt);
            }
        });

        btLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/limpar.png"))); // NOI18N
        btLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLimparActionPerformed(evt);
            }
        });

        btSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagens/sair.png"))); // NOI18N
        btSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btNovo)
                .addGap(24, 24, 24)
                .addComponent(btGravar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btEditar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btExcluir)
                .addGap(18, 18, 18)
                .addComponent(btLimpar)
                .addGap(18, 18, 18)
                .addComponent(btSair)
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btNovo, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                    .addComponent(btGravar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btLimpar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btSair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lista dos Livros", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        tbLivros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbLivros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbLivrosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbLivros);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btGravarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGravarActionPerformed
        if(lbCodigo.getText().equals(".")){
            JOptionPane.showMessageDialog(null, "Código inadequado.");
            return;
        }
        if(tfDtLivro.getText().trim().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Dt.Livro.");
            tfDtLivro.grabFocus();
            return;
        }
        if(tfTitulo.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Título.");
            tfTitulo.grabFocus();
            return;
        }
        if(tfSinopse.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Sinopse.");
            tfSinopse.grabFocus();
            return;
        }
        if(tfAno.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Ano.");
            tfAno.grabFocus();
            return;
        }
        if(tfPaginas.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Páginas.");
            tfPaginas.grabFocus();
            return;
        }
        if(tfValor.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Valor.");
            tfValor.grabFocus();
            return;
        }

        String msgImagem = imagemUpload();
        if (msgImagem.equals("Ok")) {
            cl = new ControllerLivro();
            JOptionPane.showMessageDialog(null, cl.enviarDadosLivro(lbCodigo.getText(),
                    tfTitulo.getText().trim(), tfSinopse.getText().trim(),
                    tfAno.getText(), tfPaginas.getText(), tfValor.getText(),
                    imagemDestino, tfDtLivro.getText()));
            limparCampos();
            habilitaDesabilitaBotoes(true, false, false, false, false, false);
            preencherTabela();
        } else {
            JOptionPane.showMessageDialog(null, "Selecione a imagem do Livro");
        }
    }//GEN-LAST:event_btGravarActionPerformed

    private void btEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditarActionPerformed
        if(lbCodigo.getText().equals(".")){
            JOptionPane.showMessageDialog(null, "Código inadequado.");
            return;
        }
        if(tfDtLivro.getText().trim().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Dt.Livro.");
            tfDtLivro.grabFocus();
            return;
        }
        if(tfTitulo.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Título.");
            tfTitulo.grabFocus();
            return;
        }
        if(tfSinopse.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Sinopse.");
            tfSinopse.grabFocus();
            return;
        }
        if(tfAno.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Ano.");
            tfAno.grabFocus();
            return;
        }
        if(tfPaginas.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Páginas.");
            tfPaginas.grabFocus();
            return;
        }
        if(tfValor.getText().contains(" ")){
            JOptionPane.showMessageDialog(null, "Preencha o campo Valor.");
            tfValor.grabFocus();
            return;
        }

        String msgImagem = imagemUpload();
        if (msgImagem.equals("Ok")) {
            cl = new ControllerLivro();
            JOptionPane.showMessageDialog(null, cl.editarDadosLivro(lbCodigo.getText(),
                    tfTitulo.getText().trim(), tfSinopse.getText().trim(),
                    tfAno.getText(), tfPaginas.getText(), tfValor.getText(),
                    imagemDestino, tfDtLivro.getText()));
            limparCampos();
            habilitaDesabilitaBotoes(true, false, false, false, false, false);
            preencherTabela();
        } else {
            JOptionPane.showMessageDialog(null, "Selecione a imagem do Livro");
        }
        
        limparCampos();
        habilitaDesabilitaBotoes(true, false, false, false, false, false);
        habilitaDesabilitaCampos(false, false, false, false, false, false);
    }//GEN-LAST:event_btEditarActionPerformed

    private void btExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btExcluirActionPerformed
        ControllerLivro cl = new ControllerLivro();
        JOptionPane.showMessageDialog(null, cl.enviarDadosExclusao(lbCodigo.getText()));
        limparCampos();
        habilitaDesabilitaBotoes(true, false, false, false, false, false);
        habilitaDesabilitaCampos(false, false, false, false, false, false);
        preencherTabela();
    }//GEN-LAST:event_btExcluirActionPerformed

    private void btLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btLimparActionPerformed

    private void btSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSairActionPerformed
        dispose();
    }//GEN-LAST:event_btSairActionPerformed

    private void btNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNovoActionPerformed
        limparCampos();
        habilitaDesabilitaBotoes(true, true, false, false, true, true);
        habilitaDesabilitaCampos(true, true, true, true, true, true);
        
    }//GEN-LAST:event_btNovoActionPerformed

    private void tfSinopseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfSinopseKeyPressed
        tfSinopse.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    tfAno.grabFocus();
                }
            }
        });
    }//GEN-LAST:event_tfSinopseKeyPressed

    private void btImagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btImagemActionPerformed
        if (botaoFoto == 1) {
            JFileChooser fileChooser = new JFileChooser();   //Cria o objeto do tipo Janela JFileChooser
            fileChooser.setDialogTitle("Escolha a Foto");  //Define o título do JFileChooser
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);  //Define que só serão abertos arquivos
            if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                try {
                    arquivoFoto = fileChooser.getSelectedFile();//arquivo
                    imagemOrigem = arquivoFoto.toString();
                    imagemOrigem = imagemOrigem.replace("\\", "/");
                    //pegando apenas o nome do arquivo para renomeá-lo.
                    String nomeInverso = "";
                    String x = "";
                    for (int i = imagemOrigem.length() - 1; i >= 0; i--) {
                        x = ""+imagemOrigem.charAt(i);
                        if(x.equals(".")){
                            nomeInverso += imagemOrigem.charAt(i);
                            break;
                        }else{
                            nomeInverso += imagemOrigem.charAt(i);
                        }
                    }
                    String nomeCerto = "";
                    for (int i = nomeInverso.length() - 1; i >= 0; i--) {
                        nomeCerto += nomeInverso.charAt(i);
                    }
                    //renomear o arquivo para dataHora + extensão
                    Date agora = new Date();
                    String formato = "ddMMyyyy_HHmmss";
                    DateFormat dateFormat = new SimpleDateFormat(formato);
                    imagemNovoNome = dateFormat.format(agora) + nomeCerto;
                    imagemDestino = imagemUrl + imagemNovoNome;
                    
                    //postando a foto na interface
                    String img = imagemOrigem;
                    ImageIcon imagem2 = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(150, 140, Image.SCALE_DEFAULT));
                    lbImagem.setIcon(imagem2);
                    lbImagem.setText(null);
                    /*
                    BufferedImage bi = ImageIO.read(arquivoFoto); //carrega a imagem real num buffer
                    BufferedImage aux = new BufferedImage(150, 140, bi.getType());//cria um buffer auxiliar com o tamanho desejado
                    Graphics2D g = aux.createGraphics();//pega a classe graphics do aux para edicao
                    AffineTransform at = AffineTransform.getScaleInstance((double) 150 / bi.getWidth(), (double) 140 / bi.getHeight());//cria a transformacao
                    g.drawRenderedImage(bi, at);//pinta e transforma a imagem real no auxiliar
                    lbImagem.setIcon(new ImageIcon(aux));//seta no jlabel
                    lbImagem.setText(null);
                    */

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Arquivo não encontrado" + ex.toString());
                }
             }
            botaoFoto = 2;
        }else{
            lbImagem.setIcon(null);//seta no jlabel
            lbImagem.setText("     SEM FOTO");
            botaoFoto = 1;
        }
    }//GEN-LAST:event_btImagemActionPerformed

    private void tfSinopseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfSinopseMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tfSinopseMouseClicked

    private void tbLivrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbLivrosMouseClicked
        int linhaSelecionada = tbLivros.getSelectedRow();  //pega a linha selecionada.
        //carrega os dados selecionados da jTable para os campos cpf e nome.
        lbCodigo.setText(tbLivros.getValueAt(linhaSelecionada, 0).toString());
        tfTitulo.setText(tbLivros.getValueAt(linhaSelecionada, 1).toString());
        tfSinopse.setText(tbLivros.getValueAt(linhaSelecionada, 2).toString());
        tfAno.setText(tbLivros.getValueAt(linhaSelecionada, 3).toString());
        tfPaginas.setText(tbLivros.getValueAt(linhaSelecionada, 4).toString());
        String valor = tbLivros.getValueAt(linhaSelecionada, 5).toString();
        imagemDestino = tbLivros.getValueAt(linhaSelecionada, 6).toString();
        ImageIcon imagem2 = new ImageIcon(new ImageIcon(imagemDestino).getImage().getScaledInstance(150, 140, Image.SCALE_DEFAULT));
        lbImagem.setIcon(imagem2);
        lbImagem.setText(null);
        String dataTeste = tbLivros.getValueAt(linhaSelecionada, 7).toString();//new SimpleDateFormat("dd/MM/yyyy").format();
        //JOptionPane.showMessageDialog(null, dataTeste);
        DiversosMetodos dm = new DiversosMetodos();
        dataTeste = dm.dataEngTodataPort(dataTeste);
        //JOptionPane.showMessageDialog(null, dataTeste);
        tfDtLivro.setText(dataTeste);
        valor = valor.replace(".", "");
        int contador = valor.length();
        if(contador < 5){
            String zero = "";
            while(contador < 5){
                zero += "0";
                contador++;
            }
            valor = zero + valor;
        }
        tfValor.setText(valor);
        habilitaDesabilitaBotoes(true, false, true, true, false, true);
        habilitaDesabilitaCampos(true, true, true, true, true, true);
    }//GEN-LAST:event_tbLivrosMouseClicked

    public String imagemUpload() {
        String msg1 = "Ok";
        if (!imagemOrigem.equals("") || imagemNovoNome.equals("")) {
            imagemOrigem = imagemOrigem.replace("\\", "/");
            imagemDestino = imagemDestino.replace("\\", "/");
            File source = new File(imagemOrigem);
            File destination = new File(imagemDestino);
            //JOptionPane.showMessageDialog(null, imagemOrigem);
            //JOptionPane.showMessageDialog(null, imagemDestino);
            if (destination.exists()) {
                destination.delete();
            }
            FileChannel sourceChannel = null;
            FileChannel destinationChannel = null;
            try {
                sourceChannel = new FileInputStream(source).getChannel();
                destinationChannel = new FileOutputStream(destination).getChannel();
                sourceChannel.transferTo(0, sourceChannel.size(),
                        destinationChannel);
                if (sourceChannel != null && sourceChannel.isOpen()) {
                    sourceChannel.close();
                }
                if (destinationChannel != null && destinationChannel.isOpen()) {
                    destinationChannel.close();
                }
                return msg1;
            } catch (FileNotFoundException erro) {
                msg1 = "Erro:\n" + erro.toString();
                return msg1;
            } catch (IOException erro) {
                msg1 = "Erro:\n" + erro.toString();
                return msg1;
            }
        } else {
            msg1 = "Escolha a imagem do Livro.";
            return msg1;
        }
    }
    
    public void preencherTabela(){
        ArrayList dados = new ArrayList();
        String[] colunas = new String[]{"Código","Título","Sinopse","Ano",
            "nrPaginas","Valor", "", "Dt Livro"};
        String sql = "select * from livro";
        daoLivro.executaSQL(sql);
        try{
            daoLivro.rs.first();
            do {
                dados.add(new Object[]{daoLivro.rs.getString("idLivro"),
                    daoLivro.rs.getString("titulo"),
                    daoLivro.rs.getString("sinopse"),
                    daoLivro.rs.getString("ano"),
                    daoLivro.rs.getString("nrPaginas"),
                    daoLivro.rs.getString("valor"),
                    daoLivro.rs.getString("imagem"),
                    daoLivro.rs.getDate("dataLivro")});
            } while (daoLivro.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString());
        }
        //preenchendo a JTabel tbLivros com os dados que vem do BD
        ModeloTabela mt = new ModeloTabela(dados, colunas);
        tbLivros.setModel(mt); // recebe o modelo criado
        tbLivros.getColumnModel().getColumn(0).setPreferredWidth(50);
        tbLivros.getColumnModel().getColumn(0).setResizable(false);
        tbLivros.getColumnModel().getColumn(1).setPreferredWidth(250);
        tbLivros.getColumnModel().getColumn(1).setResizable(false);
        tbLivros.getColumnModel().getColumn(2).setPreferredWidth(250);
        tbLivros.getColumnModel().getColumn(2).setResizable(false);
        tbLivros.getColumnModel().getColumn(3).setPreferredWidth(50);
        tbLivros.getColumnModel().getColumn(3).setResizable(false);
        tbLivros.getColumnModel().getColumn(4).setPreferredWidth(50);
        tbLivros.getColumnModel().getColumn(4).setResizable(false);
        tbLivros.getColumnModel().getColumn(5).setPreferredWidth(80);
        tbLivros.getColumnModel().getColumn(5).setResizable(false);
        tbLivros.getColumnModel().getColumn(6).setPreferredWidth(0);
        tbLivros.getColumnModel().getColumn(6).setResizable(false);
        tbLivros.getTableHeader().setReorderingAllowed(true);  // Não permite reordenar as colunas
        tbLivros.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); // Não permite redimensionar a tabela
        tbLivros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    //método para habilitar e desabilitar campos
    public void habilitaDesabilitaCampos(boolean c1, boolean c2, boolean c3,
            boolean c4, boolean c5, boolean c6){
        tfTitulo.setEditable(c1);
        tfSinopse.setEditable(c2);
        tfAno.setEditable(c3);
        tfPaginas.setEditable(c4);
        tfValor.setEditable(c5);
        tfDtLivro.setEditable(c6);
    }
    
    //método para habilitar e desabilitar botões
    public void habilitaDesabilitaBotoes(boolean b1, boolean b2, boolean b3,
            boolean b4, boolean b5, boolean b6){
        btNovo.setEnabled(b1);
        btGravar.setEnabled(b2);
        btEditar.setEnabled(b3);
        btExcluir.setEnabled(b4);
        btLimpar.setEnabled(b5);
        btImagem.setEnabled(b6);
    }
    
    //método para limpar todos os campos e pesquisar próximo idLivro
    public void limparCampos(){
        tfDtLivro.setText("");
        tfTitulo.setText("");
        tfSinopse.setText("");
        tfAno.setText("");
        tfPaginas.setText("");
        tfValor.setText("");
        lbImagem.setIcon(null);
        lbImagem.setText("");
        tfDtLivro.grabFocus();
        daoLivro = new DAOLivro();
        int id = daoLivro.buscarProxIdLivro();
        if(id != 0){
            lbCodigo.setText("" + id);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroLivro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroLivro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroLivro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroLivro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroLivro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEditar;
    private javax.swing.JButton btExcluir;
    private javax.swing.JButton btGravar;
    private javax.swing.JToggleButton btImagem;
    private javax.swing.JButton btLimpar;
    private javax.swing.JButton btNovo;
    private javax.swing.JButton btSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbCodigo;
    private javax.swing.JLabel lbImagem;
    private javax.swing.JTable tbLivros;
    private javax.swing.JFormattedTextField tfAno;
    private javax.swing.JFormattedTextField tfDtLivro;
    private javax.swing.JFormattedTextField tfPaginas;
    private javax.swing.JTextArea tfSinopse;
    private javax.swing.JTextField tfTitulo;
    private javax.swing.JFormattedTextField tfValor;
    // End of variables declaration//GEN-END:variables
}
