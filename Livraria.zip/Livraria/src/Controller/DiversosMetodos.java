package Controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class DiversosMetodos {
    public String dataEngTodataPort(String dataE){
        String resultado = "";
        try{
            Date dataEnglish;
            dataEnglish = new SimpleDateFormat("yyyy-MM-dd").parse(dataE);
            resultado = new SimpleDateFormat("dd/MM/yyyy").format(dataEnglish);
        }catch(Exception erro){
            JOptionPane.showMessageDialog(null, erro);
        }
        return resultado;
    }
}
