package Controller;

import Model.DAOLivro;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ControllerLivro {
    
    public String enviarDadosLivro(String codigo, String titulo, String sinopse,
            String ano, String nrPaginas, String valor, String imagem, String dataLivro){
        valor = valor.replace(".", "");
        valor = valor.replace(",", ".");
        
        // convertendo dtNascimento String em datadb Date (yyyy-MM-dd)
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate dtLivro = LocalDate.parse(dataLivro, formato);
        
        //criando objeto daoLivro e, consequentemente, um novo objeto livro na memória
        DAOLivro daoLivro = new DAOLivro();
        
        //passando os dados que vem do formulário para o objeto livro
        daoLivro.livro.setIdLivro(Integer.parseInt(codigo));
        daoLivro.livro.setTitulo(titulo);
        daoLivro.livro.setSinopse(sinopse);
        daoLivro.livro.setAno(Integer.parseInt(ano));
        daoLivro.livro.setNrPaginas(Integer.parseInt(nrPaginas));
        daoLivro.livro.setValor(Double.parseDouble(valor));
        daoLivro.livro.setImagem(imagem);
        daoLivro.livro.setDataLivro(dtLivro.toString());
        return daoLivro.inserirLivro();
    }
    
    //método para enviar dados para exclusão
    public String enviarDadosExclusao(String codigo){
        DAOLivro daoLivro = new DAOLivro();
        daoLivro.livro.setIdLivro(Integer.parseInt(codigo));
        return daoLivro.excluirLivro();
    }
    
    public String editarDadosLivro(String codigo, String titulo, String sinopse,
            String ano, String nrPaginas, String valor, String imagem, String dataLivro){
        valor = valor.replace(".", "");
        valor = valor.replace(",", ".");
        
        // convertendo dtNascimento String em datadb Date (yyyy-MM-dd)
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate dtLivro = LocalDate.parse(dataLivro, formato);
        
        //criando objeto daoLivro e, consequentemente, um novo objeto livro na memória
        DAOLivro daoLivro = new DAOLivro();
        
        //passando os dados que vem do formulário para o objeto livro
        daoLivro.livro.setIdLivro(Integer.parseInt(codigo));
        daoLivro.livro.setTitulo(titulo);
        daoLivro.livro.setSinopse(sinopse);
        daoLivro.livro.setAno(Integer.parseInt(ano));
        daoLivro.livro.setNrPaginas(Integer.parseInt(nrPaginas));
        daoLivro.livro.setValor(Double.parseDouble(valor));
        daoLivro.livro.setImagem(imagem);
        daoLivro.livro.setDataLivro(dtLivro.toString());
        return daoLivro.editarLivro();
    }
}
