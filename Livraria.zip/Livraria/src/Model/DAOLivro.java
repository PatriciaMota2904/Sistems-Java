package Model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DAOLivro {
    public Livro livro;
    private PreparedStatement pstm;
    private Statement stm;
    public ResultSet rs;
    public ConectaBD conecta;

    
    //método construtor - aloca espaço na memória com todos os objetos existentes
    public DAOLivro() {
        livro = new Livro();
    }
    
    public void executaSQL(String sql){
        try {
            /* tipo case sensitive e pode percorrer tanto do início para o 
               fim quanto do fim para o início */ 
            conecta = new ConectaBD();
            if(conecta.getConnection() == true) {
                stm = conecta.connection.createStatement(rs.TYPE_SCROLL_SENSITIVE,
                        rs.CONCUR_READ_ONLY);
                rs = stm.executeQuery(sql);
            }else{
                JOptionPane.showMessageDialog(null, "Banco fora do ar.");
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, erro);
        }
    }
    
    public int buscarProxIdLivro(){
        int id = 0;
        conecta = new ConectaBD();
        if(conecta.getConnection()==true){
            String sql = "select max(idLivro) from livro";
            try{
                stm = conecta.connection.createStatement();
                rs = stm.executeQuery(sql);
                if(rs.next()){
                    id = rs.getInt(1);
                    id++;
                }else{
                    id = 1;
                }
                conecta.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
                
        }
        return id;
    }
    
    public String inserirLivro(){
        String msg = "Cadastrado com sucesso.";
        try{
            //cria um novo objeto de conexão com BD (conecta)
            conecta = new ConectaBD();
            
            //realiza a conexão com BD
            if(conecta.getConnection() == true) {
                String sql = "insert into livro values (?,?,?,?,?,?,?,?)";
                pstm = conecta.connection.prepareStatement(sql);
                pstm.setInt(1, livro.getIdLivro());
                pstm.setString(2, livro.getTitulo());
                pstm.setString(3, livro.getSinopse());
                pstm.setInt(4, livro.getAno());
                pstm.setInt(5, livro.getNrPaginas());
                pstm.setDouble(6, livro.getValor());
                pstm.setString(7, livro.getImagem());
                pstm.setString(8, livro.getDataLivro());
                pstm.executeUpdate();
            }else{
                msg = "Não foi possível realizar o cadastro do livro.";
            }
            conecta.close();
        }catch(SQLException e1){
            msg = e1.toString();
        }
        return msg;
    }
    
    //Método de exclusão de Livros no BD
    public String excluirLivro(){
        String msg = "Excluído com sucesso.";
        try{
            //cria um novo objeto de conexão com BD (conecta)
            conecta = new ConectaBD();
            
            //realiza a conexão com BD
            if(conecta.getConnection() == true) {
                String sql = "delete from livro where idlivro = ?";
                pstm = conecta.connection.prepareStatement(sql);
                pstm.setInt(1, livro.getIdLivro());
                pstm.executeUpdate();
            }else{
                msg = "Banco fora do ar.";
            }
            conecta.close();
        }catch(SQLException e){
            msg = e.toString();
        }
        return msg;
    }
    
    public String editarLivro(){
        String msg = "Dados alterados com sucesso.";
        try{
            //cria um novo objeto de conexão com BD (conecta)
            conecta = new ConectaBD();
            
            //realiza a conexão com BD
            if(conecta.getConnection() == true) {
                String sql = "update livro set titulo = ?, sinopse = ?, "
                        + "ano = ?, nrPaginas = ?, valor = ?, imagem = ?, "
                        + "dataLivro = ? where idlivro = ?";
                pstm = conecta.connection.prepareStatement(sql);
                pstm.setString(1, livro.getTitulo());
                pstm.setString(2, livro.getSinopse());
                pstm.setInt(3, livro.getAno());
                pstm.setInt(4, livro.getNrPaginas());
                pstm.setDouble(5, livro.getValor());
                pstm.setString(6, livro.getImagem());
                pstm.setString(7, livro.getDataLivro());
                pstm.setInt(8, livro.getIdLivro());
                pstm.executeUpdate();
            }else{
                msg = "Não foi possível alterar os dados do livro.";
            }
            conecta.close();
        }catch(SQLException e1){
            msg = e1.toString();
        }
        return msg;
    }
}
